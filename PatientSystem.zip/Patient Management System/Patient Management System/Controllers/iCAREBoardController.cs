﻿using _4320_Group14_Project2.Models;
using NPOI.SS.Formula.Functions;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace _4320_Group14_Project2.Controllers
{
    public class iCAREBoardController : Controller
    {
        private iCAREEntities3 db = new iCAREEntities3();
        [HttpGet]
        public ActionResult Index()
        {
            if (string.IsNullOrEmpty(Session["UserID"].ToString()))
            {
                return RedirectToAction("Login", "UserAuthentication");
            }
            var workerID = Session["UserID"].ToString();
            var patients = db.PatientRecords.Select(p => new
            {
                p.ID,
                p.name,
                p.address,
                p.dateOfBirth,
                p.height,
                p.weight,
                p.bloodGroup,
                p.bedID,
                p.treatmentArea,
              
                numDoctors = db.TreatmentRecords.Count(t => t.patientID == p.ID && db.iCAREUsers.Any(u => u.ID == t.workerID && u.userRole == "Doctor")),
                numNurses = db.TreatmentRecords.Count(t => t.patientID == p.ID && db.iCAREUsers.Any(u => u.ID == t.workerID && u.userRole == "Nurse"))
            }).AsNoTracking().ToList();

            Dictionary<dynamic, String> pStatusList = new Dictionary<dynamic, String>();
            foreach(var p in patients)
            {
                var Status = db.TreatmentRecords.Any(t => t.patientID == p.ID) ? "Assigned" : "Unassigned";
                pStatusList.Add(p, Status);
            }

            ViewBag.patientStatus = pStatusList;
     
            return View(patients);
        }

        [HttpPost]
        public ActionResult AssignPatients(string patientID)
        {
            if (string.IsNullOrEmpty(Session["UserID"].ToString()))
            {
                return RedirectToAction("Login", "UserAuthentication");
            }

            string workerID = Session["UserID"].ToString();
            string workerRole = Session["roleName"].ToString();

            if (!string.IsNullOrEmpty(patientID))
            {
                var currentAssignment = db.TreatmentRecords.FirstOrDefault(t => t.patientID == patientID && t.workerID == workerID);
                var numDoctors = db.TreatmentRecords.Count(t => t.patientID == patientID && db.iCAREUsers.Any(u => u.ID == t.workerID && u.userRole == "Doctor"));
                var numNurses = db.TreatmentRecords.Count(t => t.patientID == patientID && db.iCAREUsers.Any(u => u.ID == t.workerID && u.userRole == "Nurse"));

                if (numNurses == 0 && String.Equals(workerRole, "Doctor"))
                {
                    ViewBag.ErrorMessage = "Patients must be assigned to a Nurse before being assigned to a Doctor.";
                    return RedirectToAction("Index", "iCAREBoard");
                }

                else if (numDoctors == 1 && String.Equals(workerRole, "Doctor"))
                {
                    ViewBag.ErrorMessage = "Patients cannot be assigned to multiple Doctors at once.";
                    return RedirectToAction("Index", "iCAREBoard");
                }

                else if (numNurses == 3 && String.Equals(workerRole, "Nurse"))
                {
                    ViewBag.ErrorMessage = "Patients cannot be assigned to more than 3 Nurses at once.";
                    return RedirectToAction("Index", "iCAREBoard");
                }
                else if (currentAssignment != null)
                {
                    ViewBag.ErrorMessage = "You are already assigned to this patient!";
                    return RedirectToAction("Index", "iCAREBoard");
                }
                db.TreatmentRecords.Add(new TreatmentRecord
                {
                    treatmentID = Guid.NewGuid().ToString(),
                    patientID = patientID,
                    workerID = workerID,
                    treatmentDate = DateTime.Now,
                    description = "Patient Assigned."
                });

                db.SaveChanges();

                TempData["Message"] = "Patient successfully assigned.";

                return RedirectToAction("Index", "iCAREBoard");
            }
            else
            {
                ViewBag.ErrorMessage = "Error Assigning Patient. Please try again.";
                return RedirectToAction("Index", "iCAREBoard");
            }
        }
        //public ActionResult AssignPatients(PatientAssign patientIDs1)
        //{
        //    var patientIDs = patientIDs1.PatientIDs;
        //    if (string.IsNullOrEmpty(Session["UserID"].ToString()))
        //    {
        //        return RedirectToAction("Login", "UserAuthentication");
        //    }

        //    string workerID = Session["UserID"].ToString();

        //    if (patientIDs != null && patientIDs.Length > 0)
        //    {
        //        foreach (var patientID in patientIDs)
        //        {
        //            var currentAssignment = db.TreatmentRecords.FirstOrDefault(t => t.patientID == patientID && t.workerID == workerID);

        //            if (currentAssignment == null)
        //            {
        //                db.TreatmentRecords.Add(new TreatmentRecord
        //                {
        //                    treatmentID = Guid.NewGuid().ToString(),
        //                    patientID = patientID,
        //                    workerID = workerID,
        //                    treatmentDate = DateTime.Now,
        //                    description = "Assigned to Worker"
        //                });




        //            }
        //            else
        //            {
        //                ViewBag.ErrorMessage = "This Patient is already assigned!";
        //                return RedirectToAction("Index", "iCAREBoard");
        //            }
        //        }
        //    }
        //    else
        //    {
        //        ViewBag.ErrorMessage = "Select a nonzero number of Patients to be assgined.";
        //        return RedirectToAction("Index", "iCAREBoard");
        //    }

        //    db.SaveChanges();
        //    return RedirectToAction("Index", "iCAREBoard");
        //}
        }
}