﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using _4320_Group14_Project2.Models;
using System.Web.Security; // For FormsAuthentication

namespace _4320_Group14_Project2.Controllers
{
    public class UserAuthenticationController : Controller
    {
        public static Boolean isLoggedIn = false;
        private iCAREEntities3 db = new iCAREEntities3();

        // GET: UserAuthentication/Login
        public ActionResult Login()
        {
            return View();
        }

        // POST: UserAuthentication/Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                string encryptedPassword = model.Password;
                var user = db.UserPasswords.FirstOrDefault(u => u.userName == model.Username);

                if (user != null && user.encryptedPassword == model.Password)
                {
                    var userName = db.iCAREUsers.FirstOrDefault(u => u.name.ToLower().Replace(" ", "") == user.userName.ToLower());

                    if (userName != null)
                    {

                        FormsAuthentication.SetAuthCookie(model.Username, model.RememberMe);
                        Session["UserID"] = user.ID;
                        Session["UserName"] = userName;
                        Session["roleName"] = userName.userRole;
                        isLoggedIn = true;

                        switch (userName.userRole)
                        {
                            case "Admin":
                                return RedirectToAction("Admin", "PostLoginHome");
                            case "Doctor":
                                return RedirectToAction("Doctor", "PostLoginHome");
                            default:
                                return RedirectToAction("Nurse", "PostLoginHome");
                        }

                    }

                    else
                    {
                        ViewBag.ErrorMessage = "Username and/or Password is incorrect. Please try again.";
                        return View(model);
                    }

                }

                else
                {
                    ViewBag.ErrorMessage = "Username and/or Password is incorrect. Please try again.";
                    return View(model);
                }
            }

            else
            {
                ViewBag.ErrorMessage = "No login provided. Try again.";
                return View(model);
            }
        }
        //public ActionResult Login(LoginViewModel model)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        // Query the database for the user
        //        var user = db.UserPasswords.FirstOrDefault(u => u.userName == model.Username);

        //        if (user != null && user.encryptedPassword == model.Password) 
        //        {
        //            // Successful login
        //            FormsAuthentication.SetAuthCookie(model.Username, model.RememberMe);
        //            if(model.Username == "admin")
        //            {
        //                isLoggedIn = true;
        //                return RedirectToAction("Admin", "PostLoginHome"); //needs to display all users and roles
        //            }
        //            else
        //            {
        //                isLoggedIn = true;
        //                return RedirectToAction("Worker", "PostLoginHome"); //needs to redirect to MyBoard
        //            }

        //        }
        //        else
        //        {
        //            ViewBag.ErrorMessage = "Username and/or password incorrect. Try again.";
        //            return View(model);
        //        }
        //    }
        //    else
        //    {
        //        ViewBag.ErrorMessage = "No login provided. Try again.";
        //        return View(model);
        //    }
        //}
        // GET: UserAuthentication/Logout
        public ActionResult Logout()
        {
            // Clear authentication and session
            FormsAuthentication.SignOut();
            Session.Clear();
            isLoggedIn = false;

            // Redirect to login page or home page
            return RedirectToAction("Login", "UserAuthentication");
        }
        // ... other controller actions (Index, Edit, Delete, etc.)

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
