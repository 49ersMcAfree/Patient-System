﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace _4320_Group14_Project2.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            if (UserAuthenticationController.isLoggedIn)
            {
                UserAuthenticationController.isLoggedIn = false;
            }
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "iCARE System Description.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Contact Us:";

            return View();
        }
    }
}