﻿using _4320_Group14_Project2.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace _4320_Group14_Project2.Controllers
{
    public class MyPaletteController : Controller
    {
        // GET: MyPalette

        iCAREEntities3 db = new iCAREEntities3();
        public static string dType;
        public static string pName;
        public static string dName;
        
        public ActionResult PaletteHome()
        {
            return View();
        }

        public ActionResult Index()
        {
            //var documents = db.DocumentMetadatas.ToList();
         

            return View();
        }

        public ActionResult UploadDocument()
        {
            return View();
        }


        [HttpPost]
        public ActionResult Upload(HttpPostedFileBase f, string patient_name, string doc_type, string doc_name)
        {
            var currentUser = User.Identity.Name;

            if (f != null && f.ContentLength > 0)
            {
                
                var patientFolderPath = Path.Combine(Server.MapPath("~/FileUploads"), currentUser, patient_name, doc_type, doc_name);

                //creating a directory if it doesn't already exits
                if (!Directory.Exists(patientFolderPath))
                {
                    Directory.CreateDirectory(patientFolderPath);
                }

                // Save the file
                var filePath = Path.Combine(patientFolderPath, Path.GetFileName(f.FileName));
                f.SaveAs(filePath);

                //storing files that will be displayed
                var files = Directory.GetFiles(patientFolderPath).Select(file => Path.GetFileName(file)).ToList();
                ViewBag.file_names = files;

                ViewBag.Message = "File uploaded successfully!";
            }
            else
            {
                ViewBag.Message = "No file uploaded!";
            }
            ViewBag.PatientName = patient_name;
            MyPaletteController.pName = patient_name;
            MyPaletteController.dName = doc_name;
            MyPaletteController.dType = doc_type;
            return View("UploadDocument");
        }


        public ActionResult DisplayDocuments(string patient_name)
        {
            var currentSignedInUser = User.Identity.Name;
            if(string.IsNullOrEmpty(patient_name))
            {
                ViewBag.Message = "Input a name!";
                return View("Index");
            }

            if(string.IsNullOrEmpty(currentSignedInUser))
            {
                ViewBag.Message = "User is not signed in";
                return View("Index");
            }

            var patientFolderPath = Path.Combine(Server.MapPath("~/FileUploads"), currentSignedInUser, patient_name);
            if (!Directory.Exists(patientFolderPath))
            {
                ViewBag.Message = "Path cannot be found!";
                return View("Index");
            }

            var f = Directory.GetFiles(patientFolderPath, "*", SearchOption.AllDirectories);

            var file_names = f.Select(file =>
            {
                var relativePath = file.Substring(patientFolderPath.Length + 1).Replace("\\", "/"); 
                return Url.Content("~/FileUploads/" + currentSignedInUser + "/" + patient_name + "/" + relativePath);
            }).ToList();
            ViewBag.file_names = file_names;
            ViewBag.PatientName = patient_name;
       
            return View("Index");

        }
        public ActionResult Download(string fileName)
        {
            var currentUser = User.Identity.Name;
            var patientFolderPath = Path.Combine(Server.MapPath("~/FileUploads"), currentUser);

            if (string.IsNullOrEmpty(fileName))
            {
                return HttpNotFound();
            }

            var filePath = Path.Combine(patientFolderPath, fileName);

            if (!System.IO.File.Exists(filePath))
            {
                return HttpNotFound();
            }

            string contentType;
            var extension = Path.GetExtension(fileName).ToLower();

            switch (extension)
            {
                case ".pdf":
                    contentType = "application/pdf";
                    break;
                case ".jpg":
                    contentType = "image/jpg";
                    break;
                case ".jpeg":
                    contentType = "image/jpeg";
                    break;
                case ".png":
                    contentType = "image/png";
                    break;
                case ".gif":
                    contentType = "image/gif";
                    break;
                default:
                    contentType = "application/octet-stream"; //default file
                    break;
            }

            return File(filePath, contentType, fileName);
        }


    }
}