﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _4320_Group14_Project2.Models
{
    public class DrugDictionaryViewModel
    {
        public string ID { get; set; }
        public string name { get; set; }
    }
}