﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace _4320_Group14_Project2.Models
{
    public class PatientAssign
    {
        [Required]
        public string[] PatientIDs { get; set; }

    }
}